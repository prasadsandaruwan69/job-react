
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import './App.css';

function App() {
  return (
<BrowserRouter>
<Routes>
  <Route element={}
</Routes>
</BrowserRouter>

    // <div className="App">
    //   <header className="App-header">
    //    <h1>Welcom to Home</h1>
    //    <button className='user-button'>User</button>
    //   </header>
    // </div>
  );
}

export default App;
