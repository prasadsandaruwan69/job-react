import Userform from "./Userform";

const  Users = () =>{
return(
<Userform />
);
}
export default Users;